import { Body, Controller, Get, Param, Post, NotFoundException } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { CreateMessageDto } from './dtos/create-message.dto';

@Controller('messages')
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  @Get()
  getMessages(): any {
    return this.messagesService.findAll();
  }

  @Get('/:id')
  async getMessageById(@Param('id') id: string): Promise<any> {
    const message = await this.messagesService.findOne(id);

    if (!message) {
      throw new NotFoundException('Message not found');
    }
    return message;
  }

  @Post()
  createMessage(@Body() body: CreateMessageDto): any {
    return this.messagesService.create(body.content);
  }
}
